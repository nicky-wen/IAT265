public class Main {
    public static void main(String[] args) throws Exception {
        EcosystemApp app = new EcosystemApp("IAT265 Ecosystem");
    }
}